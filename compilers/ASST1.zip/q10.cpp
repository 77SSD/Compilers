#include <iostream>
#include <stack>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

struct Quadruple {
    char op;
    string arg1;
    string arg2;
    string result;
};

int precedence(char op);


vector<Quadruple> generateQuadruples(const string& expression) {
    stack<char> operators;
    stack<string> operands;
    vector<Quadruple> quadruples;

    string temp;
    bool isTemp = false;

    for (char c : expression) {
        if (isdigit(c) || isalpha(c)) {
            if (isTemp) {
                temp += c;
            } else {
                operands.push(string(1, c));
            }
        } else if (c == '-') {
            if (!isTemp) {
                temp = c;
                isTemp = true;
            } else {
                temp += c;
            }
        } else if (c == '(') {
            operators.push(c);
        } else if (c == ')') {
            if (!temp.empty()) {
                operands.push(temp);
                temp.clear();
                isTemp = false;
            }
            while (!operators.empty() && operators.top() != '(') {
                char op = operators.top();
                operators.pop();
                string arg2 = operands.top();
                operands.pop();
                string arg1 = operands.top();
                operands.pop();
                string result = "(" + to_string(quadruples.size() + 1) + ")";
                operands.push(result);
                quadruples.push_back({op, arg1, arg2, result});
            }
            operators.pop(); // Discard '('
        } else {
            if (!temp.empty()) {
                string result = "(" + to_string(quadruples.size() + 1) + ")";
                operands.push(result);
                quadruples.push_back({'-', string(1, temp[1]), " ", result});
                temp.clear();
                isTemp = false;
            }
            while (!operators.empty() && precedence(operators.top()) >= precedence(c)) {
                char op = operators.top();
                operators.pop();
                string arg2 = operands.top();
                operands.pop();
                string arg1 = operands.top();
                operands.pop();
                string result = "(" + to_string(quadruples.size() + 1) + ")";
                operands.push(result);
                quadruples.push_back({op, arg1, arg2, result});
            }
            operators.push(c);
        }
    }

    if (!temp.empty()) {
        string result = "(" + to_string(quadruples.size() + 1) + ")";
        operands.push(result);
        quadruples.push_back({'-', string(1, temp[1]), " ", result});
        temp.clear();
        isTemp = false;
    }

    while (!operators.empty()) {
        char op = operators.top();
        operators.pop();
        string arg2 = operands.top();
        operands.pop();
        string arg1 = operands.top();
        operands.pop();
        if(op=='=')
            arg1.clear();
        string result = "(" + to_string(quadruples.size() + 1) + ")";
        operands.push(result);
        quadruples.push_back({op, arg1, arg2, result});
    }

    return quadruples;
}

void printTriples(const vector<Quadruple>& quadruples) {
    cout << "\nTriples:\narg1,\targ2,\top\n";
    for (const auto& quad : quadruples) {
        cout <<quad.arg1 << "\t" << quad.arg2 << "\t" << quad.op << "\n";
    }
}

int precedence(char op) {
    if (op == '/') return 4;
    if (op == '*') return 3;
    if (op == '+') return 2;
    if (op == '-') return 1;
    //if (op == '=') r
    return 0; // '('
}

int main() {
    string expression = "a=b*-c+b*-c";
    auto quadruples = generateQuadruples(expression);
    printTriples(quadruples);
    
    return 0;
}
