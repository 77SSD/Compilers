#include<iostream>
#include<vector>
using namespace std;

int main(){
    vector<string> productions;
    int n;
    cout<<"Enter number of productions:";
    cin>>n;
    for(int i=0; i<n; i++){
        string s;
        cin>>s;
        productions.push_back(s);
    }
    vector<string>non_recursive;
    for(int i=0; i<n; i++){
        char nt=productions[i][0];
        if(nt==productions[i][3]){
            string alpha,beta;
            int j=4;
            while(productions[i][j]!='|'){
                alpha.push_back(productions[i][j]);
                j++;
            }
            j++;
            while(j<productions[i].length()){
                beta.push_back(productions[i][j]);
                j++;
            }
            string r1=string(1,nt)+"->"+beta+string(1,nt)+"'";
            string r2=string(1,nt)+"'"+"->"+alpha+"'"+"|#";   //#=epsilon
            non_recursive.push_back(r1);
            non_recursive.push_back(r2);
        }
        else
            non_recursive.push_back(productions[i]);
    }
    for(auto it:non_recursive)
        cout<<it<<"\n";
}