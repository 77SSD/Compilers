#include <iostream>
#include <stack>
#include <vector>
#include <string>
#include <cctype>

using namespace std;

struct Quadruple {
    char op;
    string arg1;
    string arg2;
    string result;
};

int precedence(char op);


vector<Quadruple> generateQuadruples(const string& expression) {
    stack<char> operators;
    stack<string> operands;
    vector<Quadruple> quadruples;

    for (char c : expression) {
        if (isdigit(c) || isalpha(c)) {
            operands.push(string(1, c));
        } else if (c == '(') {
            operators.push(c);
        } else if (c == ')') {
            while (!operators.empty() && operators.top() != '(') {
                char op = operators.top();
                operators.pop();
                string arg2 = operands.top();
                operands.pop();
                string arg1 = operands.top();
                operands.pop();
                string result = "t" + to_string(quadruples.size() + 1);
                operands.push(result);
                quadruples.push_back({op, arg1, arg2, result});
            }
            operators.pop(); // Discard '('
        } else {
            while (!operators.empty() && precedence(operators.top()) >= precedence(c)) {
                char op = operators.top();
                operators.pop();
                string arg2 = operands.top();
                operands.pop();
                string arg1 = operands.top();
                operands.pop();
                string result = "t" + to_string(quadruples.size() + 1);
                operands.push(result);
                quadruples.push_back({op, arg1, arg2, result});
            }
            operators.push(c);
        }
    }

    while (!operators.empty()) {
        char op = operators.top();
        operators.pop();
        string arg2 = operands.top();
        operands.pop();
        string arg1 = operands.top();
        operands.pop();
        string result = "t" + to_string(quadruples.size() + 1);
        operands.push(result);
        quadruples.push_back({op, arg1, arg2, result});
    }

    return quadruples;
}

void printQuadruples(const vector<Quadruple>& quadruples) {
    cout << "\nQuadruples:\ntarget,\targ1,\targ2,\top\n";
    for (const auto& quad : quadruples) {
        cout << "(" << quad.result << ",\t" << quad.arg1 << ",\t" << quad.arg2 << ",\t" << quad.op << ")\n";
    }
}

int precedence(char op) {
     if (op == '/') return 4;
    if (op == '*') return 3;
    if (op == '+') return 2;
    if (op == '-') return 1;
    return 0; // '('
}

int main() {
    string expression = "a+b+c*d/e+f";
    auto quadruples = generateQuadruples(expression);
    printQuadruples(quadruples);
    return 0;
}
